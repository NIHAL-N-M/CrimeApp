# Why you haven't chosen any Face API for face recognition?

Many face detection APIs are machine learning-powered and use a neural network to perform the tasks.

# Why you chosen DBSCAN over K-Means

K-means generally clusters all the objects, DBSCAN discards objects that it defines as noise. K-means has difficulty with clusters of multiple sizes.	where as DBSCAN is used to handle clusters of multiple sizes and structures and is not powerfully influenced by noise or outliers.
